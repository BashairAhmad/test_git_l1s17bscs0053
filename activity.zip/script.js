var database = {

	username:"ali",
	password:"123"
}

var newsfeed = [{
		friend: "usman",
		status: "I am felling happy!"
},
{
	friend: "umer",
	status: "i ma felling lonely"}]		


name= prompt("Enter your name");
pass= prompt("Enter your password");

if(name==database.username && pass==database.password)
{
	console.log("valid login");
	console.log(newsfeed[0],newsfeed[1]);
	
}
else
{console.log("invalid login");}

	
